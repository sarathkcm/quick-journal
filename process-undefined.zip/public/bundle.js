
(function(l, i, v, e) { v = l.createElement(i); v.async = 1; v.src = '//' + (location.host || 'localhost').split(':')[0] + ':35729/livereload.js?snipver=1'; e = l.getElementsByTagName(i)[0]; e.parentNode.insertBefore(v, e)})(document, 'script');
var app = (function () {
    'use strict';

    function ensureBeginsWith(str, prefix) {
        if (!str) {
            return "";
        }
        return str.indexOf(prefix) === 0 ? str : prefix + str;
    }

    function defaultParseQuery(query) {
        return query ? query : "";
    }
    function defaultStringifyQuery(query) {
        return query ? query : "";
    }
    function locationUtils(options) {
        if (options === void 0) { options = {}; }
        var _a = options.query, _b = _a === void 0 ? {} : _a, _c = _b.parse, parseQuery = _c === void 0 ? defaultParseQuery : _c, _d = _b.stringify, stringifyQuery = _d === void 0 ? defaultStringifyQuery : _d, base = options.base;
        return {
            location: function (value, current) {
                var url = value.url, state = value.state;
                // special cases for empty/hash URLs
                if (url === "" || url.charAt(0) === "#") {
                    if (!current) {
                        current = { pathname: "/", hash: "", query: parseQuery() };
                    }
                    var details_1 = {
                        pathname: current.pathname,
                        hash: url.charAt(0) === "#" ? url.substring(1) : current.hash,
                        query: current.query
                    };
                    if (state) {
                        details_1.state = state;
                    }
                    return details_1;
                }
                // hash is always after query, so split it off first
                var hashIndex = url.indexOf("#");
                var hash;
                if (hashIndex !== -1) {
                    hash = url.substring(hashIndex + 1);
                    url = url.substring(0, hashIndex);
                }
                else {
                    hash = "";
                }
                var queryIndex = url.indexOf("?");
                var rawQuery;
                if (queryIndex !== -1) {
                    rawQuery = url.substring(queryIndex + 1);
                    url = url.substring(0, queryIndex);
                }
                var query = parseQuery(rawQuery);
                var pathname = base ? base.remove(url) : url;
                if (pathname === "") {
                    pathname = "/";
                }
                var details = {
                    hash: hash,
                    query: query,
                    pathname: pathname
                };
                if (state) {
                    details.state = state;
                }
                return details;
            },
            keyed: function (location, key) {
                location.key = key;
                return location;
            },
            stringify: function (location) {
                if (typeof location === "string") {
                    var firstChar = location.charAt(0);
                    if (firstChar === "#" || firstChar === "?") {
                        return location;
                    }
                    return base ? base.add(location) : location;
                }
                var pathname = location.pathname !== undefined
                    ? base
                        ? base.add(location.pathname)
                        : location.pathname
                    : "";
                return (pathname +
                    ensureBeginsWith(stringifyQuery(location.query), "?") +
                    ensureBeginsWith(location.hash, "#"));
            }
        };
    }

    function createKeyGenerator() {
        var major = 0;
        return {
            major: function (previous) {
                if (previous) {
                    major = previous[0] + 1;
                }
                return [major++, 0];
            },
            minor: function (current) {
                return [current[0], current[1] + 1];
            }
        };
    }

    function navigateWith(args) {
        var responseHandler = args.responseHandler, utils = args.utils, keygen = args.keygen, current = args.current, push = args.push, replace = args.replace;
        var pending;
        function createNavigation(location, action, finish, cancel) {
            var navigation = {
                location: location,
                action: action,
                finish: function () {
                    if (pending !== navigation) {
                        return;
                    }
                    finish();
                    pending = undefined;
                },
                cancel: function (nextAction) {
                    if (pending !== navigation) {
                        return;
                    }
                    cancel(nextAction);
                    navigation.cancelled = true;
                    pending = undefined;
                },
                cancelled: false
            };
            return navigation;
        }
        function emitNavigation(nav) {
            pending = nav;
            responseHandler(nav);
        }
        function cancelPending(action) {
            if (pending) {
                pending.cancel(action);
                pending = undefined;
            }
        }
        function prepare(to, navType) {
            var currentLocation = current();
            var location = utils.location(to, currentLocation);
            switch (navType) {
                case "anchor":
                    return utils.stringify(location) === utils.stringify(currentLocation)
                        ? replaceNav(location)
                        : pushNav(location);
                case "push":
                    return pushNav(location);
                case "replace":
                    return replaceNav(location);
                default:
                    throw new Error("Invalid navigation type: " + navType);
            }
        }
        function replaceNav(location) {
            var keyed = utils.keyed(location, keygen.minor(current().key));
            return createNavigation(keyed, "replace", replace.finish(keyed), replace.cancel);
        }
        function pushNav(location) {
            var keyed = utils.keyed(location, keygen.major(current().key));
            return createNavigation(keyed, "push", push.finish(keyed), push.cancel);
        }
        return {
            prepare: prepare,
            emitNavigation: emitNavigation,
            createNavigation: createNavigation,
            cancelPending: cancelPending
        };
    }

    function domExists() {
        return !!(window && window.location);
    }
    /*
     * Ignore popstate events that don't define event.state
     * unless they come from Chrome on iOS (because it emits
     * events where event.state is undefined when you click
     * the back button)
     */
    function ignorablePopstateEvent(event) {
        return (event.state === undefined && navigator.userAgent.indexOf("CriOS") === -1);
    }
    /*
     * IE 11 might throw, so just catch and return empty object when that happens
     */
    function getStateFromHistory() {
        try {
            return window.history.state || {};
        }
        catch (e) {
            return {};
        }
    }

    function noop() { }
    function browser(fn, options) {
        if (options === void 0) { options = {}; }
        if (!domExists()) {
            throw new Error("Cannot use @hickory/browser without a DOM");
        }
        var utils = locationUtils(options);
        var keygen = createKeyGenerator();
        function fromBrowser(providedState) {
            var _a = window.location, pathname = _a.pathname, search = _a.search, hash = _a.hash;
            var url = pathname + search + hash;
            var _b = providedState || getStateFromHistory(), key = _b.key, state = _b.state;
            if (!key) {
                key = keygen.major();
                window.history.replaceState({ key: key, state: state }, "", url);
            }
            var location = utils.location({ url: url, state: state });
            return utils.keyed(location, key);
        }
        function url(location) {
            return utils.stringify(location);
        }
        // set action before location because fromBrowser enforces
        // that the location has a key
        var lastAction = getStateFromHistory().key !== undefined ? "pop" : "push";
        var _a = navigateWith({
            responseHandler: fn,
            utils: utils,
            keygen: keygen,
            current: function () { return browserHistory.location; },
            push: {
                finish: function (location) {
                    return function () {
                        var path = url(location);
                        var key = location.key, state = location.state;
                        try {
                            window.history.pushState({ key: key, state: state }, "", path);
                        }
                        catch (e) {
                            window.location.assign(path);
                        }
                        browserHistory.location = location;
                        lastAction = "push";
                    };
                },
                cancel: noop
            },
            replace: {
                finish: function (location) {
                    return function () {
                        var path = url(location);
                        var key = location.key, state = location.state;
                        try {
                            window.history.replaceState({ key: key, state: state }, "", path);
                        }
                        catch (e) {
                            window.location.replace(path);
                        }
                        browserHistory.location = location;
                        lastAction = "replace";
                    };
                },
                cancel: noop
            }
        }), emitNavigation = _a.emitNavigation, cancelPending = _a.cancelPending, createNavigation = _a.createNavigation, prepare = _a.prepare;
        // when true, pop will ignore the navigation
        var reverting = false;
        function popstate(event) {
            if (reverting) {
                reverting = false;
                return;
            }
            if (ignorablePopstateEvent(event)) {
                return;
            }
            cancelPending("pop");
            var location = fromBrowser(event.state);
            var diff = browserHistory.location.key[0] - location.key[0];
            emitNavigation(createNavigation(location, "pop", function () {
                browserHistory.location = location;
                lastAction = "pop";
            }, function (nextAction) {
                if (nextAction === "pop") {
                    return;
                }
                reverting = true;
                window.history.go(diff);
            }));
        }
        window.addEventListener("popstate", popstate, false);
        var browserHistory = {
            location: fromBrowser(),
            current: function () {
                emitNavigation(createNavigation(browserHistory.location, lastAction, noop, noop));
            },
            url: url,
            cancel: function () {
                cancelPending();
            },
            destroy: function () {
                window.removeEventListener("popstate", popstate);
                emitNavigation = noop;
            },
            navigate: function (to, navType) {
                if (navType === void 0) { navType = "anchor"; }
                var navigation = prepare(to, navType);
                cancelPending(navigation.action);
                emitNavigation(navigation);
            },
            go: function (num) {
                window.history.go(num);
            }
        };
        return browserHistory;
    }

    function pathname(route, params) {
        return route.methods.pathname(params);
    }

    /**
     * Expose `pathToRegexp`.
     */
    var pathToRegexp_1 = pathToRegexp;
    var parse_1 = parse;
    var compile_1 = compile;
    var tokensToFunction_1 = tokensToFunction;
    var tokensToRegExp_1 = tokensToRegExp;

    /**
     * Default configs.
     */
    var DEFAULT_DELIMITER = '/';
    var DEFAULT_DELIMITERS = './';

    /**
     * The main path matching regexp utility.
     *
     * @type {RegExp}
     */
    var PATH_REGEXP = new RegExp([
      // Match escaped characters that would otherwise appear in future matches.
      // This allows the user to escape special characters that won't transform.
      '(\\\\.)',
      // Match Express-style parameters and un-named parameters with a prefix
      // and optional suffixes. Matches appear as:
      //
      // ":test(\\d+)?" => ["test", "\d+", undefined, "?"]
      // "(\\d+)"  => [undefined, undefined, "\d+", undefined]
      '(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?'
    ].join('|'), 'g');

    /**
     * Parse a string for the raw tokens.
     *
     * @param  {string}  str
     * @param  {Object=} options
     * @return {!Array}
     */
    function parse (str, options) {
      var tokens = [];
      var key = 0;
      var index = 0;
      var path = '';
      var defaultDelimiter = (options && options.delimiter) || DEFAULT_DELIMITER;
      var delimiters = (options && options.delimiters) || DEFAULT_DELIMITERS;
      var pathEscaped = false;
      var res;

      while ((res = PATH_REGEXP.exec(str)) !== null) {
        var m = res[0];
        var escaped = res[1];
        var offset = res.index;
        path += str.slice(index, offset);
        index = offset + m.length;

        // Ignore already escaped sequences.
        if (escaped) {
          path += escaped[1];
          pathEscaped = true;
          continue
        }

        var prev = '';
        var next = str[index];
        var name = res[2];
        var capture = res[3];
        var group = res[4];
        var modifier = res[5];

        if (!pathEscaped && path.length) {
          var k = path.length - 1;

          if (delimiters.indexOf(path[k]) > -1) {
            prev = path[k];
            path = path.slice(0, k);
          }
        }

        // Push the current path onto the tokens.
        if (path) {
          tokens.push(path);
          path = '';
          pathEscaped = false;
        }

        var partial = prev !== '' && next !== undefined && next !== prev;
        var repeat = modifier === '+' || modifier === '*';
        var optional = modifier === '?' || modifier === '*';
        var delimiter = prev || defaultDelimiter;
        var pattern = capture || group;

        tokens.push({
          name: name || key++,
          prefix: prev,
          delimiter: delimiter,
          optional: optional,
          repeat: repeat,
          partial: partial,
          pattern: pattern ? escapeGroup(pattern) : '[^' + escapeString(delimiter) + ']+?'
        });
      }

      // Push any remaining characters.
      if (path || index < str.length) {
        tokens.push(path + str.substr(index));
      }

      return tokens
    }

    /**
     * Compile a string to a template function for the path.
     *
     * @param  {string}             str
     * @param  {Object=}            options
     * @return {!function(Object=, Object=)}
     */
    function compile (str, options) {
      return tokensToFunction(parse(str, options))
    }

    /**
     * Expose a method for transforming tokens into the path function.
     */
    function tokensToFunction (tokens) {
      // Compile all the tokens into regexps.
      var matches = new Array(tokens.length);

      // Compile all the patterns before compilation.
      for (var i = 0; i < tokens.length; i++) {
        if (typeof tokens[i] === 'object') {
          matches[i] = new RegExp('^(?:' + tokens[i].pattern + ')$');
        }
      }

      return function (data, options) {
        var path = '';
        var encode = (options && options.encode) || encodeURIComponent;

        for (var i = 0; i < tokens.length; i++) {
          var token = tokens[i];

          if (typeof token === 'string') {
            path += token;
            continue
          }

          var value = data ? data[token.name] : undefined;
          var segment;

          if (Array.isArray(value)) {
            if (!token.repeat) {
              throw new TypeError('Expected "' + token.name + '" to not repeat, but got array')
            }

            if (value.length === 0) {
              if (token.optional) continue

              throw new TypeError('Expected "' + token.name + '" to not be empty')
            }

            for (var j = 0; j < value.length; j++) {
              segment = encode(value[j], token);

              if (!matches[i].test(segment)) {
                throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '"')
              }

              path += (j === 0 ? token.prefix : token.delimiter) + segment;
            }

            continue
          }

          if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
            segment = encode(String(value), token);

            if (!matches[i].test(segment)) {
              throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but got "' + segment + '"')
            }

            path += token.prefix + segment;
            continue
          }

          if (token.optional) {
            // Prepend partial segment prefixes.
            if (token.partial) path += token.prefix;

            continue
          }

          throw new TypeError('Expected "' + token.name + '" to be ' + (token.repeat ? 'an array' : 'a string'))
        }

        return path
      }
    }

    /**
     * Escape a regular expression string.
     *
     * @param  {string} str
     * @return {string}
     */
    function escapeString (str) {
      return str.replace(/([.+*?=^!:${}()[\]|/\\])/g, '\\$1')
    }

    /**
     * Escape the capturing group by escaping special characters and meaning.
     *
     * @param  {string} group
     * @return {string}
     */
    function escapeGroup (group) {
      return group.replace(/([=!:$/()])/g, '\\$1')
    }

    /**
     * Get the flags for a regexp from the options.
     *
     * @param  {Object} options
     * @return {string}
     */
    function flags (options) {
      return options && options.sensitive ? '' : 'i'
    }

    /**
     * Pull out keys from a regexp.
     *
     * @param  {!RegExp} path
     * @param  {Array=}  keys
     * @return {!RegExp}
     */
    function regexpToRegexp (path, keys) {
      if (!keys) return path

      // Use a negative lookahead to match only capturing groups.
      var groups = path.source.match(/\((?!\?)/g);

      if (groups) {
        for (var i = 0; i < groups.length; i++) {
          keys.push({
            name: i,
            prefix: null,
            delimiter: null,
            optional: false,
            repeat: false,
            partial: false,
            pattern: null
          });
        }
      }

      return path
    }

    /**
     * Transform an array into a regexp.
     *
     * @param  {!Array}  path
     * @param  {Array=}  keys
     * @param  {Object=} options
     * @return {!RegExp}
     */
    function arrayToRegexp (path, keys, options) {
      var parts = [];

      for (var i = 0; i < path.length; i++) {
        parts.push(pathToRegexp(path[i], keys, options).source);
      }

      return new RegExp('(?:' + parts.join('|') + ')', flags(options))
    }

    /**
     * Create a path regexp from string input.
     *
     * @param  {string}  path
     * @param  {Array=}  keys
     * @param  {Object=} options
     * @return {!RegExp}
     */
    function stringToRegexp (path, keys, options) {
      return tokensToRegExp(parse(path, options), keys, options)
    }

    /**
     * Expose a function for taking tokens and returning a RegExp.
     *
     * @param  {!Array}  tokens
     * @param  {Array=}  keys
     * @param  {Object=} options
     * @return {!RegExp}
     */
    function tokensToRegExp (tokens, keys, options) {
      options = options || {};

      var strict = options.strict;
      var start = options.start !== false;
      var end = options.end !== false;
      var delimiter = escapeString(options.delimiter || DEFAULT_DELIMITER);
      var delimiters = options.delimiters || DEFAULT_DELIMITERS;
      var endsWith = [].concat(options.endsWith || []).map(escapeString).concat('$').join('|');
      var route = start ? '^' : '';
      var isEndDelimited = tokens.length === 0;

      // Iterate over the tokens and create our regexp string.
      for (var i = 0; i < tokens.length; i++) {
        var token = tokens[i];

        if (typeof token === 'string') {
          route += escapeString(token);
          isEndDelimited = i === tokens.length - 1 && delimiters.indexOf(token[token.length - 1]) > -1;
        } else {
          var capture = token.repeat
            ? '(?:' + token.pattern + ')(?:' + escapeString(token.delimiter) + '(?:' + token.pattern + '))*'
            : token.pattern;

          if (keys) keys.push(token);

          if (token.optional) {
            if (token.partial) {
              route += escapeString(token.prefix) + '(' + capture + ')?';
            } else {
              route += '(?:' + escapeString(token.prefix) + '(' + capture + '))?';
            }
          } else {
            route += escapeString(token.prefix) + '(' + capture + ')';
          }
        }
      }

      if (end) {
        if (!strict) route += '(?:' + delimiter + ')?';

        route += endsWith === '$' ? '$' : '(?=' + endsWith + ')';
      } else {
        if (!strict) route += '(?:' + delimiter + '(?=' + endsWith + '))?';
        if (!isEndDelimited) route += '(?=' + delimiter + '|' + endsWith + ')';
      }

      return new RegExp(route, flags(options))
    }

    /**
     * Normalize the given path string, returning a regular expression.
     *
     * An empty array can be passed in for the keys, which will hold the
     * placeholder key descriptions. For example, using `/user/:id`, `keys` will
     * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
     *
     * @param  {(string|RegExp|Array)} path
     * @param  {Array=}                keys
     * @param  {Object=}               options
     * @return {!RegExp}
     */
    function pathToRegexp (path, keys, options) {
      if (path instanceof RegExp) {
        return regexpToRegexp(path, keys)
      }

      if (Array.isArray(path)) {
        return arrayToRegexp(/** @type {!Array} */ (path), keys, options)
      }

      return stringToRegexp(/** @type {string} */ (path), keys, options)
    }
    pathToRegexp_1.parse = parse_1;
    pathToRegexp_1.compile = compile_1;
    pathToRegexp_1.tokensToFunction = tokensToFunction_1;
    pathToRegexp_1.tokensToRegExp = tokensToRegExp_1;

    function isAsyncRoute(route) {
        return typeof route.methods.resolve !== "undefined";
    }
    function isExternalRedirect(redirect) {
        return "externalURL" in redirect;
    }

    function finishResponse(route, match, resolvedResults, router, external) {
        var _a = resolvedResults || {}, _b = _a.resolved, resolved = _b === void 0 ? null : _b, _c = _a.error, error = _c === void 0 ? null : _c;
        var response = {
            data: undefined,
            body: undefined,
            meta: undefined
        };
        for (var key in match) {
            response[key] = match[key];
        }
        if (!route.methods.respond) {
            return response;
        }
        var results = route.methods.respond({
            resolved: resolved,
            error: error,
            match: match,
            external: external
        });
        if (!results) {
            if (process.env.NODE_ENV !== "production") {
                console.warn("\"" + match.name + "\"'s response function did not return anything. Did you forget to include a return statement?");
            }
            return response;
        }
        if (process.env.NODE_ENV !== "production") {
            var validProperties_1 = {
                meta: true,
                body: true,
                data: true,
                redirect: true
            };
            Object.keys(results).forEach(function (property) {
                if (!validProperties_1.hasOwnProperty(property)) {
                    console.warn("\"" + property + "\" is not a valid response property. The valid properties are:\n\n  " + Object.keys(validProperties_1).join(", "));
                }
            });
        }
        response["meta"] = results["meta"];
        response["body"] = results["body"];
        response["data"] = results["data"];
        if (results["redirect"]) {
            response["redirect"] = createRedirect(results["redirect"], router);
        }
        return response;
    }
    function createRedirect(redirect, router) {
        if (isExternalRedirect(redirect)) {
            return redirect;
        }
        var name = redirect.name, params = redirect.params, query = redirect.query, hash = redirect.hash, state = redirect.state;
        var url = router.url({ name: name, params: params, query: query, hash: hash });
        return {
            name: name,
            params: params,
            query: query,
            hash: hash,
            state: state,
            url: url
        };
    }

    function createRouter(historyConstructor, routes, options) {
        if (options === void 0) { options = {}; }
        var latestResponse;
        var latestNavigation;
        var history = historyConstructor(function (pendingNav) {
            var navigation = {
                action: pendingNav.action,
                previous: latestResponse
            };
            var matched = routes.match(pendingNav.location);
            if (!matched) {
                if (process.env.NODE_ENV !== "production") {
                    console.warn("The current location (" + pendingNav.location.pathname + ") has no matching route, " +
                        'so a response could not be emitted. A catch-all route ({ path: "(.*)" }) ' +
                        "can be used to match locations with no other matching route.");
                }
                pendingNav.finish();
                finishAndResetNavCallbacks();
                return;
            }
            var route = matched.route, match = matched.match;
            if (!isAsyncRoute(route)) {
                finalizeResponseAndEmit(route, match, pendingNav, navigation, null);
            }
            else {
                announceAsyncNav();
                route.methods
                    .resolve(match, options.external)
                    .then(function (resolved) { return ({ resolved: resolved, error: null }); }, function (error) { return ({ error: error, resolved: null }); })
                    .then(function (resolved) {
                    if (pendingNav.cancelled) {
                        return;
                    }
                    finalizeResponseAndEmit(route, match, pendingNav, navigation, resolved);
                });
            }
        }, options.history || {});
        function finalizeResponseAndEmit(route, match, pending, navigation, resolved) {
            asyncNavComplete();
            pending.finish();
            var response = finishResponse(route, match, resolved, router, options.external);
            finishAndResetNavCallbacks();
            emitImmediate(response, navigation);
        }
        var _a = options.invisibleRedirects, invisibleRedirects = _a === void 0 ? false : _a;
        function emitImmediate(response, navigation) {
            if (!response.redirect ||
                !invisibleRedirects ||
                isExternalRedirect(response.redirect)) {
                latestResponse = response;
                latestNavigation = navigation;
                var emit = { response: response, navigation: navigation, router: router };
                callObservers(emit);
                callOneTimersAndSideEffects(emit);
            }
            if (response.redirect !== undefined &&
                !isExternalRedirect(response.redirect)) {
                history.navigate(response.redirect, "replace");
            }
        }
        function callObservers(emitted) {
            observers.forEach(function (fn) {
                fn(emitted);
            });
        }
        function callOneTimersAndSideEffects(emitted) {
            oneTimers.splice(0).forEach(function (fn) {
                fn(emitted);
            });
            if (options.sideEffects) {
                options.sideEffects.forEach(function (fn) {
                    fn(emitted);
                });
            }
        }
        /* router.observer & router.once */
        var observers = [];
        var oneTimers = [];
        function observe(fn, options) {
            var _a = (options || {}).initial, initial = _a === void 0 ? true : _a;
            observers.push(fn);
            if (latestResponse && initial) {
                fn({
                    response: latestResponse,
                    navigation: latestNavigation,
                    router: router
                });
            }
            return function () {
                observers = observers.filter(function (obs) {
                    return obs !== fn;
                });
            };
        }
        function once(fn, options) {
            var _a = (options || {}).initial, initial = _a === void 0 ? true : _a;
            if (latestResponse && initial) {
                fn({
                    response: latestResponse,
                    navigation: latestNavigation,
                    router: router
                });
            }
            else {
                oneTimers.push(fn);
            }
        }
        /* router.url */
        function url(details) {
            var name = details.name, params = details.params, hash = details.hash, query = details.query;
            var pathname$1;
            if (name) {
                var route = router.route(name);
                if (route) {
                    pathname$1 = pathname(route, params);
                }
            }
            return history.url({ pathname: pathname$1, hash: hash, query: query });
        }
        /* router.navigate */
        var cancelCallback;
        var finishCallback;
        function navigate(details) {
            cancelAndResetNavCallbacks();
            var url = details.url, state = details.state, method = details.method;
            history.navigate({ url: url, state: state }, method);
            if (details.cancelled || details.finished) {
                cancelCallback = details.cancelled;
                finishCallback = details.finished;
                return resetCallbacks;
            }
        }
        function cancelAndResetNavCallbacks() {
            if (cancelCallback) {
                cancelCallback();
            }
            resetCallbacks();
        }
        function finishAndResetNavCallbacks() {
            if (finishCallback) {
                finishCallback();
            }
            resetCallbacks();
        }
        function resetCallbacks() {
            cancelCallback = undefined;
            finishCallback = undefined;
        }
        /* router.cancel */
        var cancelWith;
        var asyncNavNotifiers = [];
        function cancel(fn) {
            asyncNavNotifiers.push(fn);
            return function () {
                asyncNavNotifiers = asyncNavNotifiers.filter(function (can) {
                    return can !== fn;
                });
            };
        }
        // let any async navigation listeners (observers from router.cancel)
        // know that there is an asynchronous navigation happening
        function announceAsyncNav() {
            if (asyncNavNotifiers.length && cancelWith === undefined) {
                cancelWith = function () {
                    history.cancel();
                    asyncNavComplete();
                    cancelAndResetNavCallbacks();
                };
                asyncNavNotifiers.forEach(function (fn) {
                    fn(cancelWith);
                });
            }
        }
        function asyncNavComplete() {
            if (cancelWith) {
                cancelWith = undefined;
                asyncNavNotifiers.forEach(function (fn) {
                    fn();
                });
            }
        }
        var router = {
            route: routes.route,
            history: history,
            external: options.external,
            observe: observe,
            once: once,
            cancel: cancel,
            url: url,
            navigate: navigate,
            current: function () {
                return {
                    response: latestResponse,
                    navigation: latestNavigation
                };
            },
            destroy: function () {
                history.destroy();
            }
        };
        history.current();
        return router;
    }

    var withLeadingSlash = function (path) {
        return path.charAt(0) === "/" ? path : "/" + path;
    };
    var withTrailingSlash = function (path) {
        return path.charAt(path.length - 1) === "/" ? path : path + "/";
    };
    var join = function (beginning, end) {
        return withTrailingSlash(beginning) + end;
    };

    function createRoute(props, map, parent) {
        if (parent === void 0) { parent = {
            path: "",
            keys: []
        }; }
        if (process.env.NODE_ENV !== "production") {
            if (props.name in map) {
                throw new Error("Multiple routes have the name \"" + props.name + "\". Route names must be unique.");
            }
            if (props.path.charAt(0) === "/") {
                throw new Error("Route paths cannot start with a forward slash (/). (Received \"" + props.path + "\")");
            }
        }
        var fullPath = withLeadingSlash(join(parent.path, props.path));
        var _a = props.pathOptions || {}, _b = _a.match, matchOptions = _b === void 0 ? {} : _b, _c = _a.compile, compileOptions = _c === void 0 ? {} : _c;
        // end must be false for routes with children, but we want to track its original value
        var exact = matchOptions.end == null || matchOptions.end;
        if (props.children && props.children.length) {
            matchOptions.end = false;
        }
        var keys = [];
        var re = pathToRegexp_1(withLeadingSlash(props.path), keys, matchOptions);
        var keyNames = keys.map(function (key) { return key.name; });
        if (parent.keys.length) {
            keyNames = parent.keys.concat(keyNames);
        }
        var childRoutes = [];
        var children = [];
        if (props.children && props.children.length) {
            childRoutes = props.children.map(function (child) {
                return createRoute(child, map, {
                    path: fullPath,
                    keys: keyNames
                });
            });
            children = childRoutes.map(function (child) { return child.public; });
        }
        var compiled = pathToRegexp_1.compile(fullPath);
        var route = {
            public: {
                name: props.name,
                keys: keyNames,
                parent: undefined,
                children: children,
                methods: {
                    resolve: props.resolve,
                    respond: props.respond,
                    pathname: function (params) {
                        return compiled(params, compileOptions);
                    }
                },
                extra: props.extra
            },
            matching: {
                re: re,
                keys: keys,
                exact: exact,
                parsers: props.params || {},
                children: childRoutes
            }
        };
        map[props.name] = route.public;
        if (childRoutes.length) {
            childRoutes.forEach(function (child) {
                child.public.parent = route.public;
            });
        }
        return route;
    }

    function matchLocation(location, routes) {
        for (var i = 0, len = routes.length; i < len; i++) {
            var routeMatches = matchRoute(routes[i], location.pathname);
            if (routeMatches.length) {
                return createMatch(routeMatches, location);
            }
        }
    }
    function matchRoute(route, pathname) {
        var _a = route.matching, re = _a.re, children = _a.children, exact = _a.exact;
        var regExpMatch = re.exec(pathname);
        if (!regExpMatch) {
            return [];
        }
        var matchedSegment = regExpMatch[0], parsed = regExpMatch.slice(1);
        var matches = [{ route: route, parsed: parsed }];
        var remainder = pathname.slice(matchedSegment.length);
        if (!children.length || remainder === "") {
            return matches;
        }
        // match that ends with a strips it from the remainder
        var fullSegments = withLeadingSlash(remainder);
        for (var i = 0, length_1 = children.length; i < length_1; i++) {
            var matched = matchRoute(children[i], fullSegments);
            if (matched.length) {
                return matches.concat(matched);
            }
        }
        return exact ? [] : matches;
    }
    function createMatch(routeMatches, location) {
        var route = routeMatches[routeMatches.length - 1].route.public;
        return {
            route: route,
            match: {
                location: location,
                name: route.name,
                params: routeMatches.reduce(function (params, _a) {
                    var route = _a.route, parsed = _a.parsed;
                    parsed.forEach(function (param, index) {
                        var name = route.matching.keys[index].name;
                        var fn = route.matching.parsers[name] || decodeURIComponent;
                        params[name] = fn(param);
                    });
                    return params;
                }, {})
            }
        };
    }

    function prepareRoutes(routes) {
        var mappedRoutes = {};
        var prepared = routes.map(function (route) { return createRoute(route, mappedRoutes); });
        return {
            match: function (location) {
                return matchLocation(location, prepared);
            },
            route: function (name) {
                if (process.env.NODE_ENV !== "production" && !(name in mappedRoutes)) {
                    console.warn("Attempting to use route \"" + name + "\", but no route with that name exists.");
                }
                return mappedRoutes[name];
            }
        };
    }

    function announce(fmt, mode) {
        if (mode === void 0) { mode = "assertive"; }
        var announcer = document.createElement("div");
        announcer.setAttribute("aria-live", mode);
        // https://hugogiraudel.com/2016/10/13/css-hide-and-seek/
        announcer.setAttribute("style", [
            "border: 0 !important;",
            "clip: rect(1px, 1px, 1px, 1px) !important;",
            "-webkit-clip-path: inset(50%) !important;",
            "clip-path: inset(50%) !important;",
            "height: 1px !important;",
            "overflow: hidden !important;",
            "padding: 0 !important;",
            "position: absolute !important;",
            "width: 1px !important;",
            "white-space: nowrap !important;",
            "top: 0;"
        ].join(" "));
        document.body.appendChild(announcer);
        return function (emitted) {
            announcer.textContent = fmt(emitted);
        };
    }

    function noop$1() { }
    function assign(tar, src) {
        for (const k in src)
            tar[k] = src[k];
        return tar;
    }
    function run(fn) {
        return fn();
    }
    function blank_object() {
        return Object.create(null);
    }
    function run_all(fns) {
        fns.forEach(run);
    }
    function is_function(thing) {
        return typeof thing === 'function';
    }
    function safe_not_equal(a, b) {
        return a != a ? b == b : a !== b || ((a && typeof a === 'object') || typeof a === 'function');
    }
    function validate_store(store, name) {
        if (!store || typeof store.subscribe !== 'function') {
            throw new Error(`'${name}' is not a store with a 'subscribe' method`);
        }
    }
    function subscribe(component, store, callback) {
        const unsub = store.subscribe(callback);
        component.$$.on_destroy.push(unsub.unsubscribe
            ? () => unsub.unsubscribe()
            : unsub);
    }
    function create_slot(definition, ctx, fn) {
        if (definition) {
            const slot_ctx = get_slot_context(definition, ctx, fn);
            return definition[0](slot_ctx);
        }
    }
    function get_slot_context(definition, ctx, fn) {
        return definition[1]
            ? assign({}, assign(ctx.$$scope.ctx, definition[1](fn ? fn(ctx) : {})))
            : ctx.$$scope.ctx;
    }
    function get_slot_changes(definition, ctx, changed, fn) {
        return definition[1]
            ? assign({}, assign(ctx.$$scope.changed || {}, definition[1](fn ? fn(changed) : {})))
            : ctx.$$scope.changed || {};
    }
    function insert(target, node, anchor) {
        target.insertBefore(node, anchor || null);
    }
    function detach(node) {
        node.parentNode.removeChild(node);
    }
    function text(data) {
        return document.createTextNode(data);
    }
    function empty() {
        return text('');
    }
    function children(element) {
        return Array.from(element.childNodes);
    }

    let current_component;
    function set_current_component(component) {
        current_component = component;
    }
    function get_current_component() {
        if (!current_component)
            throw new Error(`Function called outside component initialization`);
        return current_component;
    }
    function setContext(key, context) {
        get_current_component().$$.context.set(key, context);
    }
    function getContext(key) {
        return get_current_component().$$.context.get(key);
    }

    const dirty_components = [];
    const resolved_promise = Promise.resolve();
    let update_scheduled = false;
    const binding_callbacks = [];
    const render_callbacks = [];
    const flush_callbacks = [];
    function schedule_update() {
        if (!update_scheduled) {
            update_scheduled = true;
            resolved_promise.then(flush);
        }
    }
    function add_render_callback(fn) {
        render_callbacks.push(fn);
    }
    function flush() {
        const seen_callbacks = new Set();
        do {
            // first, call beforeUpdate functions
            // and update components
            while (dirty_components.length) {
                const component = dirty_components.shift();
                set_current_component(component);
                update(component.$$);
            }
            while (binding_callbacks.length)
                binding_callbacks.shift()();
            // then, once components are updated, call
            // afterUpdate functions. This may cause
            // subsequent updates...
            while (render_callbacks.length) {
                const callback = render_callbacks.pop();
                if (!seen_callbacks.has(callback)) {
                    callback();
                    // ...so guard against infinite loops
                    seen_callbacks.add(callback);
                }
            }
        } while (dirty_components.length);
        while (flush_callbacks.length) {
            flush_callbacks.pop()();
        }
        update_scheduled = false;
    }
    function update($$) {
        if ($$.fragment) {
            $$.update($$.dirty);
            run_all($$.before_render);
            $$.fragment.p($$.dirty, $$.ctx);
            $$.dirty = null;
            $$.after_render.forEach(add_render_callback);
        }
    }
    let outros;
    function group_outros() {
        outros = {
            remaining: 0,
            callbacks: []
        };
    }
    function check_outros() {
        if (!outros.remaining) {
            run_all(outros.callbacks);
        }
    }
    function on_outro(callback) {
        outros.callbacks.push(callback);
    }
    function mount_component(component, target, anchor) {
        const { fragment, on_mount, on_destroy, after_render } = component.$$;
        fragment.m(target, anchor);
        // onMount happens after the initial afterUpdate. Because
        // afterUpdate callbacks happen in reverse order (inner first)
        // we schedule onMount callbacks before afterUpdate callbacks
        add_render_callback(() => {
            const new_on_destroy = on_mount.map(run).filter(is_function);
            if (on_destroy) {
                on_destroy.push(...new_on_destroy);
            }
            else {
                // Edge case - component was destroyed immediately,
                // most likely as a result of a binding initialising
                run_all(new_on_destroy);
            }
            component.$$.on_mount = [];
        });
        after_render.forEach(add_render_callback);
    }
    function destroy(component, detaching) {
        if (component.$$) {
            run_all(component.$$.on_destroy);
            component.$$.fragment.d(detaching);
            // TODO null out other refs, including component.$$ (but need to
            // preserve final state?)
            component.$$.on_destroy = component.$$.fragment = null;
            component.$$.ctx = {};
        }
    }
    function make_dirty(component, key) {
        if (!component.$$.dirty) {
            dirty_components.push(component);
            schedule_update();
            component.$$.dirty = blank_object();
        }
        component.$$.dirty[key] = true;
    }
    function init(component, options, instance, create_fragment, not_equal$$1, prop_names) {
        const parent_component = current_component;
        set_current_component(component);
        const props = options.props || {};
        const $$ = component.$$ = {
            fragment: null,
            ctx: null,
            // state
            props: prop_names,
            update: noop$1,
            not_equal: not_equal$$1,
            bound: blank_object(),
            // lifecycle
            on_mount: [],
            on_destroy: [],
            before_render: [],
            after_render: [],
            context: new Map(parent_component ? parent_component.$$.context : []),
            // everything else
            callbacks: blank_object(),
            dirty: null
        };
        let ready = false;
        $$.ctx = instance
            ? instance(component, props, (key, value) => {
                if ($$.ctx && not_equal$$1($$.ctx[key], $$.ctx[key] = value)) {
                    if ($$.bound[key])
                        $$.bound[key](value);
                    if (ready)
                        make_dirty(component, key);
                }
            })
            : props;
        $$.update();
        ready = true;
        run_all($$.before_render);
        $$.fragment = create_fragment($$.ctx);
        if (options.target) {
            if (options.hydrate) {
                $$.fragment.l(children(options.target));
            }
            else {
                $$.fragment.c();
            }
            if (options.intro && component.$$.fragment.i)
                component.$$.fragment.i();
            mount_component(component, options.target, options.anchor);
            flush();
        }
        set_current_component(parent_component);
    }
    class SvelteComponent {
        $destroy() {
            destroy(this, true);
            this.$destroy = noop$1;
        }
        $on(type, callback) {
            const callbacks = (this.$$.callbacks[type] || (this.$$.callbacks[type] = []));
            callbacks.push(callback);
            return () => {
                const index = callbacks.indexOf(callback);
                if (index !== -1)
                    callbacks.splice(index, 1);
            };
        }
        $set() {
            // overridden by instance, if it has props
        }
    }
    class SvelteComponentDev extends SvelteComponent {
        constructor(options) {
            if (!options || (!options.target && !options.$$inline)) {
                throw new Error(`'target' is a required option`);
            }
            super();
        }
        $destroy() {
            super.$destroy();
            this.$destroy = () => {
                console.warn(`Component was already destroyed`); // eslint-disable-line no-console
            };
        }
    }

    /* src\App\Components\DayView.svelte generated by Svelte v3.4.4 */

    function create_fragment(ctx) {
    	var t;

    	return {
    		c: function create() {
    			t = text("Hello");
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			insert(target, t, anchor);
    		},

    		p: noop$1,
    		i: noop$1,
    		o: noop$1,

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(t);
    			}
    		}
    	};
    }

    class DayView extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, null, create_fragment, safe_not_equal, []);
    	}
    }

    //window.process = window.process || { env: {} };
    const routes = prepareRoutes([
        {
            name: "Day",
            path: "",
            respond() {
                return {
                    body: {
                        main: DayView,
                    }
                }
            }
        },
    ]);

    /**
     * Creates a `Readable` store that allows reading by subscription.
     * @param value initial value
     * @param {StartStopNotifier}start start and stop notifications for subscriptions
     */
    function readable(value, start) {
        return {
            subscribe: writable(value, start).subscribe,
        };
    }
    /**
     * Create a `Writable` store that allows both updating and reading by subscription.
     * @param {*=}value initial value
     * @param {StartStopNotifier=}start start and stop notifications for subscriptions
     */
    function writable(value, start = noop$1) {
        let stop;
        const subscribers = [];
        function set(new_value) {
            if (safe_not_equal(value, new_value)) {
                value = new_value;
                if (!stop) {
                    return; // not ready
                }
                subscribers.forEach((s) => s[1]());
                subscribers.forEach((s) => s[0](value));
            }
        }
        function update(fn) {
            set(fn(value));
        }
        function subscribe(run, invalidate = noop$1) {
            const subscriber = [run, invalidate];
            subscribers.push(subscriber);
            if (subscribers.length === 1) {
                stop = start(set) || noop$1;
            }
            run(value);
            return () => {
                const index = subscribers.indexOf(subscriber);
                if (index !== -1) {
                    subscribers.splice(index, 1);
                }
                if (subscribers.length === 0) {
                    stop();
                }
            };
        }
        return { set, update, subscribe };
    }

    var routerKey = {};
    var responseKey = {};
    var navigationKey = {};
    function setup(router) {
      var initial = router.current();
      var response = readable(initial.response, function (set) {
        return router.observe(function (_ref) {
          var response = _ref.response;
          set(response);
        });
      });
      var navigation = readable(initial.navigation, function (set) {
        return router.observe(function (_ref2) {
          var navigation = _ref2.navigation;
          set(navigation);
        });
      });
      setContext(routerKey, router);
      setContext(responseKey, response);
      setContext(navigationKey, navigation);
    }
    function getResponse() {
      return getContext(responseKey);
    }

    /* node_modules\@curi\svelte\components\Router.svelte generated by Svelte v3.4.4 */

    function create_fragment$1(ctx) {
    	var current;

    	const default_slot_1 = ctx.$$slots.default;
    	const default_slot = create_slot(default_slot_1, ctx, null);

    	return {
    		c: function create() {
    			if (default_slot) default_slot.c();
    		},

    		l: function claim(nodes) {
    			if (default_slot) default_slot.l(nodes);
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			if (default_slot) {
    				default_slot.m(target, anchor);
    			}

    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (default_slot && default_slot.p && changed.$$scope) {
    				default_slot.p(get_slot_changes(default_slot_1, ctx, changed, null), get_slot_context(default_slot_1, ctx, null));
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			if (default_slot && default_slot.i) default_slot.i(local);
    			current = true;
    		},

    		o: function outro(local) {
    			if (default_slot && default_slot.o) default_slot.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (default_slot) default_slot.d(detaching);
    		}
    	};
    }

    function instance($$self, $$props, $$invalidate) {
    	let { router } = $$props;

      setup(router);

    	const writable_props = ['router'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<Router> was created with unknown prop '${key}'`);
    	});

    	let { $$slots = {}, $$scope } = $$props;

    	$$self.$set = $$props => {
    		if ('router' in $$props) $$invalidate('router', router = $$props.router);
    		if ('$$scope' in $$props) $$invalidate('$$scope', $$scope = $$props.$$scope);
    	};

    	return { router, $$slots, $$scope };
    }

    class Router extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance, create_fragment$1, safe_not_equal, ["router"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.router === undefined && !('router' in props)) {
    			console.warn("<Router> was created without expected prop 'router'");
    		}
    	}

    	get router() {
    		throw new Error("<Router>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set router(value) {
    		throw new Error("<Router>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    /* src\App\Layouts\Default.Layout.svelte generated by Svelte v3.4.4 */

    function create_fragment$2(ctx) {
    	var switch_instance_anchor, current;

    	var switch_value = ctx.$response.body.main;

    	function switch_props(ctx) {
    		return { $$inline: true };
    	}

    	if (switch_value) {
    		var switch_instance = new switch_value(switch_props(ctx));
    	}

    	return {
    		c: function create() {
    			if (switch_instance) switch_instance.$$.fragment.c();
    			switch_instance_anchor = empty();
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			if (switch_instance) {
    				mount_component(switch_instance, target, anchor);
    			}

    			insert(target, switch_instance_anchor, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			if (switch_value !== (switch_value = ctx.$response.body.main)) {
    				if (switch_instance) {
    					group_outros();
    					const old_component = switch_instance;
    					on_outro(() => {
    						old_component.$destroy();
    					});
    					old_component.$$.fragment.o(1);
    					check_outros();
    				}

    				if (switch_value) {
    					switch_instance = new switch_value(switch_props(ctx));

    					switch_instance.$$.fragment.c();
    					switch_instance.$$.fragment.i(1);
    					mount_component(switch_instance, switch_instance_anchor.parentNode, switch_instance_anchor);
    				} else {
    					switch_instance = null;
    				}
    			}
    		},

    		i: function intro(local) {
    			if (current) return;
    			if (switch_instance) switch_instance.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			if (switch_instance) switch_instance.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			if (detaching) {
    				detach(switch_instance_anchor);
    			}

    			if (switch_instance) switch_instance.$destroy(detaching);
    		}
    	};
    }

    function instance$1($$self, $$props, $$invalidate) {
    	let $response;

    	const response = getResponse(); validate_store(response, 'response'); subscribe($$self, response, $$value => { $response = $$value; $$invalidate('$response', $response); });

    	return { response, $response };
    }

    class Default_Layout extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$1, create_fragment$2, safe_not_equal, []);
    	}
    }

    /* src\App\App.svelte generated by Svelte v3.4.4 */

    // (13:0) <Router {router}>
    function create_default_slot(ctx) {
    	var current;

    	var defaultlayout = new Default_Layout({ $$inline: true });

    	return {
    		c: function create() {
    			defaultlayout.$$.fragment.c();
    		},

    		m: function mount(target, anchor) {
    			mount_component(defaultlayout, target, anchor);
    			current = true;
    		},

    		i: function intro(local) {
    			if (current) return;
    			defaultlayout.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			defaultlayout.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			defaultlayout.$destroy(detaching);
    		}
    	};
    }

    function create_fragment$3(ctx) {
    	var current;

    	var router_1 = new Router({
    		props: {
    		router: ctx.router,
    		$$slots: { default: [create_default_slot] },
    		$$scope: { ctx }
    	},
    		$$inline: true
    	});

    	return {
    		c: function create() {
    			router_1.$$.fragment.c();
    		},

    		l: function claim(nodes) {
    			throw new Error("options.hydrate only works if the component was compiled with the `hydratable: true` option");
    		},

    		m: function mount(target, anchor) {
    			mount_component(router_1, target, anchor);
    			current = true;
    		},

    		p: function update(changed, ctx) {
    			var router_1_changes = {};
    			if (changed.router) router_1_changes.router = ctx.router;
    			if (changed.$$scope) router_1_changes.$$scope = { changed, ctx };
    			router_1.$set(router_1_changes);
    		},

    		i: function intro(local) {
    			if (current) return;
    			router_1.$$.fragment.i(local);

    			current = true;
    		},

    		o: function outro(local) {
    			router_1.$$.fragment.o(local);
    			current = false;
    		},

    		d: function destroy(detaching) {
    			router_1.$destroy(detaching);
    		}
    	};
    }

    function instance$2($$self, $$props, $$invalidate) {
    	
      let { router } = $$props;

    	const writable_props = ['router'];
    	Object.keys($$props).forEach(key => {
    		if (!writable_props.includes(key) && !key.startsWith('$$')) console.warn(`<App> was created with unknown prop '${key}'`);
    	});

    	$$self.$set = $$props => {
    		if ('router' in $$props) $$invalidate('router', router = $$props.router);
    	};

    	return { router };
    }

    class App extends SvelteComponentDev {
    	constructor(options) {
    		super(options);
    		init(this, options, instance$2, create_fragment$3, safe_not_equal, ["router"]);

    		const { ctx } = this.$$;
    		const props = options.props || {};
    		if (ctx.router === undefined && !('router' in props)) {
    			console.warn("<App> was created without expected prop 'router'");
    		}
    	}

    	get router() {
    		throw new Error("<App>: Props cannot be read directly from the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}

    	set router(value) {
    		throw new Error("<App>: Props cannot be set directly on the component instance unless compiling with 'accessors: true' or '<svelte:options accessors/>'");
    	}
    }

    const router = createRouter(browser, routes, {
    	sideEffects: [
    		announce(({ response }) => {
    			return `Navigated to ${response.location.pathname}`;
    		})
    	]
    });
    const app = new App({
    	target: document.body,
    	props: {
    		router
    	}
    });

    return app;

}());
//# sourceMappingURL=bundle.js.map
